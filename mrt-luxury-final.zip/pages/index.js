export default function Home() {
  return (
    <div style={{ fontFamily: 'Arial', padding: 40 }}>
      <h1>MRT LUXURY INVESTMENTS</h1>
      <p>Welcome to your real estate investment hub.</p>
    </div>
  );
}